﻿#include <iostream>
#include <string>

using namespace std;

int main() {
  string string_value("Hello");
  cout << string_value << endl;

  string_value = "World!";
  cout << string_value << endl;

  return 0;
}
