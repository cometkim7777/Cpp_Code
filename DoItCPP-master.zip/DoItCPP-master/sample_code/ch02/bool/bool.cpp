﻿#include <iostream>

using namespace std;

int main() {
  bool value;

  value = true;
  cout << value << endl;

  value = false;
  cout << value << endl;

  return 0;
}
