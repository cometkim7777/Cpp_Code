﻿#include <iostream>
#include <string>

using namespace std;

int main() {
  string str1("Hello");
  cout << str1 << endl;

  cout << str1.length() << endl;
  cout << str1.size() << endl;

  return 0;
}
