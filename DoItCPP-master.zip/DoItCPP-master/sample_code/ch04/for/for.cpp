﻿#include <iostream>

using namespace std;

int main() {
  for (int count = 0; count < 5; count++) {
    cout << " count : " << count << endl;
  }
  return 0;
}
