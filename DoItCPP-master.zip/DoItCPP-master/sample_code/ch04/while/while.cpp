﻿#include <iostream>

using namespace std;

int main() {
  int count = 0;
  while (count < 5) {
    cout << "count : " << count << endl;
    count++;
  }
  return 0;
}
